const chatBox = document.getElementById("chat-box");
const userInput = document.getElementById("user-input");
const sendBtn = document.getElementById("send-btn");
const chatContainer = document.querySelector('.chat-container');

const menuBtn = document.getElementById('menu-btn');
const sidebar = document.querySelector('.sidebar');
const overlay = document.querySelector('.sidebar-overlay');
const closeBtn = document.querySelector('.close-btn');

let currentChatFile = null; // 🧠 File chat đang dùng

// ===============================
// 📱 Sidebar toggle
// ===============================
function toggleSidebar() {
  sidebar.classList.toggle('active');
  overlay.classList.toggle('active');
}

menuBtn.addEventListener('click', () => {
  toggleSidebar();
  loadHistoryList();
});
overlay.addEventListener('click', toggleSidebar);
closeBtn.addEventListener('click', toggleSidebar);

// ✅ URL server
const BASE_URL = window.location.origin.includes("file://")
  ? "http://127.0.0.1:3000"
  : window.location.origin;

// ===============================
// 💬 Thêm tin nhắn vào khung
// ===============================
function addMessage(content, className) {
  const message = document.createElement("div");
  message.className = className;
  message.textContent = content;
  chatBox.appendChild(message);
  chatBox.scrollTop = chatBox.scrollHeight;
  return message;
}

// ===============================
// ✍️ Hiệu ứng gõ chữ
// ===============================
function typeMessage(element, text, speed = 35) {
  return new Promise(resolve => {
    let i = 0;
    const interval = setInterval(() => {
      if (i < text.length) {
        element.textContent += text.charAt(i);
        i++;
        chatBox.scrollTop = chatBox.scrollHeight;
      } else {
        clearInterval(interval);
        resolve();
      }
    }, speed);
  });
}

// ===============================
// 💭 Hiệu ứng "bot đang gõ"
// ===============================
async function showTypingIndicator(duration = 1500) {
  const typing = addMessage("...", "bot-message typing");
  let dots = 0;
  const interval = setInterval(() => {
    dots = (dots + 1) % 4;
    typing.textContent = ".".repeat(dots);
  }, 400);

  return new Promise(resolve => {
    setTimeout(() => {
      clearInterval(interval);
      typing.remove();
      resolve();
    }, duration);
  });
}

// ===============================
// 📤 Gửi tin nhắn
// ===============================
async function sendMessage() {
  const userText = userInput.value.trim();
  if (!userText) return;

  userInput.disabled = true;
  sendBtn.disabled = true;

  addMessage(userText, "user-message");
  userInput.value = "";

  try {
    const res = await fetch(`${BASE_URL}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: userText }),
    });

    if (!res.ok) throw new Error("Server not reachable");

    const data = await res.json();
    await showTypingIndicator(1500);

    if (data && data.content) {
      const msgBox = addMessage("", "bot-message");
      await typeMessage(msgBox, data.content);
      if (data.historyFile) currentChatFile = data.historyFile; // 🧠 cập nhật file chat hiện tại
    } else {
      const msgBox = addMessage("", "bot-message");
      await typeMessage(msgBox, "😅 Mình chưa hiểu ý bạn, thử nói lại nhé!");
    }
  } catch (err) {
    console.error("⚠️ Lỗi:", err);
    const msg = addMessage("", "bot-message");
    await typeMessage(msg, "⚠️ Lỗi kết nối với server!");
  } finally {
    userInput.disabled = false;
    sendBtn.disabled = false;
    userInput.focus();
  }
}

// Gửi khi nhấn nút hoặc Enter
sendBtn.addEventListener("click", sendMessage);
userInput.addEventListener("keypress", e => {
  if (e.key === "Enter") sendMessage();
});

// ===============================
// 📏 Điều chỉnh chiều cao chat box
// ===============================
function adjustChatHeight() {
  chatContainer.style.height = `${window.innerHeight * 0.85}px`;
}
adjustChatHeight();
window.addEventListener("resize", adjustChatHeight);

// ===============================
// 🕑 Tải danh sách lịch sử
// ===============================
async function loadHistoryList() {
  const list = document.getElementById("history-list");
  if (!list) return;
  list.innerHTML = "<li>⏳ Đang tải...</li>";

  try {
    const res = await fetch(`${BASE_URL}/history/list`);
    const data = await res.json();

    if (data.success && data.files.length > 0) {
      list.innerHTML = "";
      data.files.forEach(file => {
        const li = document.createElement("li");
        li.className = "history-item";
        li.innerHTML = `💬 ${file.name.replace(".json", "")}`;
        li.addEventListener("click", async () => {
          await selectChat(file.name);
          loadHistory(file.name);
        });
        list.appendChild(li);
      });
    } else {
      list.innerHTML = "<li>Không có đoạn chat nào.</li>";
    }
  } catch (err) {
    console.error("❌ Lỗi tải lịch sử:", err);
    list.innerHTML = "<li>⚠️ Không thể tải danh sách.</li>";
  }
}

// ===============================
// 📖 Tải nội dung chat cũ
// ===============================
async function loadHistory(fileName) {
  chatBox.innerHTML = "<div class='bot-message'>⏳ Đang tải...</div>";
  try {
    const res = await fetch(`${BASE_URL}/history/${fileName}`);
    const data = await res.json();

    chatBox.innerHTML = "";
    if (data.success && data.history.length > 0) {
      data.history.forEach(item => {
        if (item.role === "user") addMessage(item.message, "user-message");
        else addMessage(item.message, "bot-message");
      });
    } else {
      addMessage("Không có nội dung trong đoạn chat này.", "bot-message");
    }

    currentChatFile = fileName;
    console.log("📂 Đang chat trong:", fileName);
  } catch (err) {
    console.error("❌ Lỗi tải đoạn chat:", err);
    addMessage("⚠️ Không thể tải đoạn chat!", "bot-message");
  }

  toggleSidebar();
}

// ===============================
// 🧭 Gửi yêu cầu chọn file chat hiện tại
// ===============================
async function selectChat(fileName) {
  try {
    const res = await fetch(`${BASE_URL}/chat/select`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ file: fileName }),
    });
    const data = await res.json();
    if (data.success) {
      currentChatFile = fileName;
      console.log(`✅ Đang tiếp tục chat trong: ${fileName}`);
    }
  } catch (err) {
    console.error("❌ Lỗi chọn file:", err);
  }
}

// ===============================
// 🆕 Tạo đoạn chat mới
// ===============================
document.querySelector(".new-chat")?.addEventListener("click", async () => {
  try {
    await fetch(`${BASE_URL}/chat/new`, { method: "POST" });
    currentChatFile = null;
    chatBox.innerHTML = "";
    addMessage("🆕 Bắt đầu một đoạn chat mới nào!", "bot-message");
    toggleSidebar();
  } catch (err) {
    console.error("❌ Lỗi tạo đoạn chat mới:", err);
  }
});